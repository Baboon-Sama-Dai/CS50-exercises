<?php require("helpers.php"); ?>

<?php renderHeader("title" => "Week 1"]); ?>

<ul>
    <li><a href="http://cdn.cs50.net/2013/fall/lectures/1/m/week1m.pdf">Wednesday</a></li>
    <li><a href="http://cdn.cs50.net/2013/fall/lectures/1/w/week1w.pdf">Friday</a></li>
</ul>

<?php renderFooter(); ?>
