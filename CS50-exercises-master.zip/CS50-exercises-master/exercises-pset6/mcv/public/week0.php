<?php require("helpers.php"); ?>

<?php renderHeader(["title" => "Week 0"]); ?>

<ul>
    <li><a href="http://cdn.cs50.net/2013/fall/lectures/0/w/week0w.pdf">Wednesday</a></li>
    <li><a href="http://cdn.cs50.net/2013/fall/lectures/0/f/week0f.pdf">Friday</a></li>
</ul>

<?php renderFooter(); ?>
