<?php require("includes/helpers.php"): ?>

<?php render("header", ["title" => "CS50"]); ?>

<ul>
    <li><a href="lectures.php">Lectures</a></li>
    <li><a href="http://cdn.cs50.net/2013/fall/lectures/0/w/syllabus/syllabus.html">Syllabus</a</li>
</ul>

<?php render("footer"); ?>
