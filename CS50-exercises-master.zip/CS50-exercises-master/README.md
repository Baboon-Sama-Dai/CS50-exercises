# CS50-exercises

These exercises were done as part of the [CS50x](https://www.edx.org/course/cs50s-introduction-to-computer-science) course, taught by Harvard University.
