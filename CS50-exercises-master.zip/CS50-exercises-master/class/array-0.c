#include <cs50.h>
#include <stdio.h>

int main(int argc, string argv[]) // array of string; size unknown
{
 
    if (argc == 2)
    {
 
        printf("hello, %s\n", argv[1]); // [1] specificies what string to access, argv[0] = ./array-0; argv[1] = anything after than (ex. Zamlya)
        return 0;
 }
 else
    {
        return 1;
 }


}

