<form action="deposit.php" method="post">
<p> Please type how much money you want to deposit </p>
    <fieldset>
        <fieldset>
        <div class="form-group">
            <input autofocus class="form-control" name="cash" placeholder="Amount" type="text"/>
        </div>
        <div class="form-group">
            <button class="btn btn-default" type="submit">Deposit</button>
        </div>
    </fieldset>
    </fieldset>
</form>

