<?php	require("../includes/config.php");

	render("history-form.php", ["title" => "History"]);


				
?>
