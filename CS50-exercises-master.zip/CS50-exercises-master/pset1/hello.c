#include <stdio.h>

int main(void)
{
    // prints hello, world
    printf("hello, world\n");
}
