#include <stdio.h>
#include <cs50.h>

int main(void)
{
    //• In C, it is possible to create an
    //if–else if-else chain.
    //• In Scratch, this required nesting
    //blocks.
    //• As you would expect, each
    //branch is mutually exclusive.

    int x = get_int("Choose a number between 0 and 50 to see what happen: ");
    if(x < 30)
    {
        //first branch
        printf("%i is less than 30", x);
    }
    else if (x > 30)
    {
        //second branch
        printf("%i is higher than 30", x);
    }
    else if (x == 30)
    {
        //third branch
        printf("%i is equal to 30", x);
    }
    else
    {
        //fourth branch
        printf("What the hell is this???");
    }
}
