#include <stdio.h>
#include <cs50.h>

int main(void)
{
    // "Forever loop".

    //This is what we call an infinite loop. The lines of codebetween
    //the curly braces will execute repeatedly from topto bottom,
    //until and unless we break out of it (as with abreak; statement) or otherwise kill our program.

    //  while its "true" execute the loop until it return the value "false".
    while(true)
    {
        printf("30\n");
        return false;
    }

    //  "Repeat until" (loop + counter).

    //If the boolean-expr evaluates to true, all lines of code
    //between the curly braces will execute repeatedly, in order
    //from top-to-bottom, until boolean-expr evaluates to false.
    //Somewhat confusingly, the behavior of the Scratch block is
    //reversed, but it is the closest analog.

    //  Initialize a variable then "while" is "true" increment x by 1(x++) until x == 100.
    int x = 0;
    while(x <= 100)
    {
        printf("%i\n", x);
        x++;
    }
}
