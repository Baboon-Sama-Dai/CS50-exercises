#include <stdio.h>
#include <cs50.h>

int main(void)
{
    //INPUT AND PRINTING
    //GET AN INPUT FROM THE USER WITH A "FUNCTION CALL" get_int("");
    int calls = get_int("Calls: ");
    //THE USER GIVES US A VALUE FOR EXAMPLE 4
    //WE GOT UNDER THE HOOD "int calls = 4"

    //TO SEE ON THE SCREEN THE VALUE GIVEN BY THE USER WE NEED ANOTHER FUNCTION CALLED "Printf("");"
    //THE 'f' of printf... means "format"
    printf("calls is %i\n", calls);
    //THIS WILL SHOW ON THE SCREEN "calls is 4"
    //TO CALL THE VALUE OF A VARIABLE WE USE THE MODULUS'%' FOLLOWED BY THE APROPIATE LETTER, IN THAT CASE WE'VE USED 'i' FOR INTEGER.
    //EXAMPLE OF TYPES AND FORMAT CODES: int(%i); float(%f); char(%c); string(%s)etc...
}
