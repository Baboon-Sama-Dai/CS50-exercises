#include <stdio.h>
#include <cs50.h>

int main(void)
{
    //• C’s switch() statement is a
    //conditional statement that permits
    //enumeration of discrete cases,
    //instead of relying on Boolean
    //expressions.
    //• It’s important to break; between
    //each case, or you will “fall through”
    //each case (unless that is desired
    //behavior).
    int x = get_int("");
    switch(x)
    {
        case 1:
            printf("One!\n");
            break;
        case 2:
            printf("Two!\n");
            break;
        case 3:
            printf("Three!\n");
            break;
        case 4:
            printf("Sorry...\n");
            break;
    }
}
