#include <stdio.h>
#include <cs50.h>

int main(void)
{
    //Syntactically unattractive, but for loops are used to repeat the
    //body of a loop a specified number of times, in this example 10.
    //• The process undertaken in a for loop is:
    //• The counter variable(s) (here, i) is set
    //• The Boolean expression is checked.
    //• If it evaluates to true, the body of the loop executes.
    //• If it evaluates to false, the body of the loop does not
    //execute.
    //• The counter variable is incremented, and then the
    //Boolean expression is checked again, etc.

    //"Repeat" then stop
    for (int i = 0; i < 3; i++)
        printf("Ma man!!!\n");
}
