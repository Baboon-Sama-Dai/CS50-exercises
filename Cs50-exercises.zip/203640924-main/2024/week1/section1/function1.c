#include <stdio.h>
#include <cs50.h>

//FUNCTION
    //PYRAMID
        //#
        //##
        //###
        //####
void print_row(int length);

int main(void)
{
    //
    int height = get_int("Height: ");

    for (int i = 1; i <= height; i++)//Or (int i = 0; i <= height; i++)
    {
        print_row(i);
        //Or (i + 1)
    }

}

void print_row(int length)
{
    for (int i = 0; i < length; i++)
    {
        printf("#");
    }
    printf("\n");
}
