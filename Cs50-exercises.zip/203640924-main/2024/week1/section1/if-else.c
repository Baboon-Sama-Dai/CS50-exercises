#include <stdio.h>
#include <cs50.h>

int main(void)
{

    //If the boolean-expression evaluates to true, all lines
    //of code between the first set of curly braces will execute in
    //order from top-to-bottom.
    //• If the boolean-expression evaluates to false, all lines
    //of code between the second set of curly braces will execute
    //in order from top-to-bottom.

    int x = get_int("Please choose a number under or higher than 10: ");
    if(x < 10)
    {
        printf("Yeah!\n");
    }
    else
    {
        printf("Nooo!\n");
    }
}
