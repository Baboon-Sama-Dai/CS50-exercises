#include <stdio.h>
#include <cs50.h>

int main(void)
{
// WHAT IS A VARIABLE?
    //A VARIABLE IS A NAME FOR A VALUE THAT CAN CHANGE.
    //
    int calls = 3;
    //INT = TYPE
    //CALLS = NAME OF THE VARIABLE
    //'3' = VALUE
    //'=' IS AN "ASSIGNMENT OPERATOR" THAT TRANSFERT THE VALUE FROM THE RIGHT (INTEGER'3') TO THE LEFT INTO OUR VARIABLE "CALLS" USED AS A CONTAINER


    //HOW TO READ THAT LIGNE OF CODE IN ONE SENTENCE (BELOW)
    int country_code = 65;
    //"WE CREATE AN INTEGER VARIABLE NAMED "country_code" THAT GETS THE VALUE 65."
    printf("%i\n", calls);


    //WHY HAVE DATA TYPES?
    //TO KNOW WHERE TO ALLOCATE OUR INFORMATIONS/VALUES IN THE CORRECT SPACE TO OPTIMAZE OUR STORAGE/MEMORY.
    //65 = 01000001
    char country_code = 65;
    //IF USING CHAR TO STORE THE VARIABLE 65 THEN 65 IS NOW EQUAL TO 'A' )(ASCII CHART)


    //int calls = 4;
    //calls = calls + 2;
    //calls = calls - 1;
    //calls = calls * 2;
    //calls = calls / 2;

    //SYNTACTIC SUGAR
    int calls = 4;
    calls += 2;
    calls -= 1;
    calls *= 2;
    calls /= 2;
    //CALLS AT THE END IS EQUAL TO 5

    //TRUNCATION
        int calls = 4;
    calls += 1;
    calls -= 2;
    calls *= 3;
    calls /= 2;
    //CALLS AT THE END IS EQUAL TO 4 INSTEAD OF 4.5(MATHEMATICLY CORRECT)
    //BECAUSE WE ARE CALCULATING AN INTEGER AND INTEGER DOES NOT INCLUDE FLOATING NUMBER ONLY NEGATIVE/POSITIVE WITHOUT DECIMAL ETC...


}
