#include <stdio.h>
#include <cs50.h>

int main(void)
{
    //This loop will execute all lines
    //of code between the curly
    //braces (at least once), and then, if the
    //boolean-expr evaluates to
    //true, will go back and repeat
    //that process until booleanexpr evaluates to false.
    do
    {
        printf("Man");
        return false;
    }
    while (true);
}
