#include <stdio.h>
#include <cs50.h>

int main(void)
{
    //These two snippets of code act identically.
    //• The ternary operator (?:) is mostly a cute trick, but is
    //useful for writing trivially short conditional branches. Be
    //familiar with it, but know that you won’t need to write it if
    //you don’t want to.

    //int x;
    //if()
    //{
    //    x = 5;
    //}
    //else
    //{
    //    x = 6;
    //}

    int x = (6 == 3 + 4 ) ? 5 : 6;
        printf("%i", x);
}
