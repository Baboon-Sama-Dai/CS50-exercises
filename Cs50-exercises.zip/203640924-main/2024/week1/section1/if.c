#include <stdio.h>
#include <cs50.h>

int main(void)
{
    //If the boolean-expression evaluates to true, all lines
    //of code between the curly braces will execute in order from
    //top-to-bottom.
    //• If the boolean-expression evaluates to false, those
    //lines of code will not execute.

    int x = 0;
    if(x < 10)
    {
        printf("Ma Man!");
    }
}
