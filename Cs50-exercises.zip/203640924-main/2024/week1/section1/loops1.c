#include <stdio.h>
#include <cs50.h>

//FUNCTION / LOOPS / CONDITIONAL

int main(void)
{
    //WHILE LOOP

    //int j = 0;
    //while (j < 4)
    //{
    //    printf("#");
    //    j++;
    //}
    //printf("\n");

    //FOR LOOP
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            printf("#");
        }
        printf("\n");
    }
}
