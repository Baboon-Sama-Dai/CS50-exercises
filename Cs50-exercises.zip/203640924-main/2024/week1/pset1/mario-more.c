#include <cs50.h>
#include <stdio.h>

// Inicialize the function.
void print_row(int spaces, int length, int col_right);

int main(void)
{
    // Ask the user for the height between 1 and 8 inclusive.
    int height;
    do
    {
        height = get_int("Height: ");
    }
    while (height < 1 || height > 8);

    // Print the ressult using our function with 2 arguments.
    for (int i = 0; i < height; i++)
    {
        print_row(height - i, i + 1, i + 1);
    }
}
// Create a function with 2 arguments
// First print the number of spaces - 1 from length.
// Second print the number of '#' define by the user (Left colon).
// Third print spaces (--) between the two colon
// Fourth print the print the number of '#' define by the user (right colon).
void print_row(int spaces, int length, int col_right)
{
    for (int j = 1; j <= spaces; j++)
    {
        printf(" ");
    }

    for (int k = 0; k < length; k++)
    {
        printf("#");
    }

    printf("|  |");

    for (int l = 0; l < col_right; l++)
    {
        printf("#");
    }
    printf("\n");
}
