#include <cs50.h>
#include <stdio.h>

// START WITH AN EXAMPLE OF 41.

// Inicialize the functions
int calculate_quarters(int cents);
int calculate_dimes(int cents);
int calculate_nickels(int cents);
int calculate_pennies(int cents);

int main(void)
{
    // Prompt the user for change owed, in variable cents type integer
    int cents;
    // Start a do while loop to at least execute the code once
    do
    {
        // Get input from user and store it in our variable cents
        cents = get_int("Change owed: ");
    }
    // Asking the user for an specific input by allowding only number from 0 to infinite positiv number (As an integer can contained at leat)
    while (cents < 0);

    // Create a variable type integer where to store the return value of our function aswell type integer.
    int quarters = calculate_quarters(cents);
    // Calculating the reminder by time the sum of result from the return value by 25(quarter) and substracting that value from cents.
    cents = cents - (quarters * 25);
    // Then cents become of the result above 16
    // keep going until done


    int dimes = calculate_dimes(cents);
    cents = cents - (dimes * 10);

    int nickels = calculate_nickels(cents);
    cents = cents - (nickels * 5);

    int pennies = calculate_pennies(cents);
    cents = cents - (pennies * 1);

    // Add all the return values to a int variable call "sum"
    int sum = quarters + dimes + nickels + pennies;
    printf("Quarters: %i Dimes: %i Nickels: %i Pennies: %i\n", quarters, dimes, nickels, pennies);
    printf("The sum of coins is: %i\n", sum);
}
// ET VOILA!

// Create a function that return a value type integer with one argument called cents
int calculate_quarters(int cents)
{
    // inicialize the variable "quarter" as an "Integer" to '0'
    int quarters = 0; // ()=1 after loop)
    // Create a while loop to check how many time we found a quarter(25)
    // Keep looping each time that cents is bigger or equal to 25.
    while (cents >= 25)
    {
        // increment quarters by 1 )(quarters is now 1 )
        quarters++;
        // Actualize the variable cents(input from user) by substracting a quarter(25) cents is now equal to 41-25 = 16
        cents = cents - 25;
    }
    return quarters; // in that case return '1'
}// Sama sama for the rest.
int calculate_dimes(int cents)
{
    int dimes = 0;
    while (cents >= 10)
    {
        dimes++;
        cents = cents - 10;
    }
    return dimes;
}
int calculate_nickels(int cents)
{
    int nickels = 0;
    while (cents >= 5)
    {
        nickels++;
        cents = cents - 5;
    }
    return nickels;
}
int calculate_pennies(int cents)
{
    int pennies = 0;
    while (cents >= 1)
    {
        pennies++;
        cents = cents - 1;
    }
    return pennies;
}

// Calculate how many quarters you should give customer
// Subtract the value of those quarters from cents

// Calculate how many dimes you should give customer
// Subtract the value of those dimes from remaining cents

// Calculate how many nickels you should give customer
// Subtract the value of those nickels from remaining cents

// Calculate how many pennies you should give customer
// Subtract the value of those pennies from remaining cents

// Sum the number of quarters, dimes, nickels, and pennies used
//= Print that sum

//SIMPLER WAY!!!
// USING MODULUS '%'

//      #include <cs50.h>
//      #include <stdio.h>
//
//      int main(void)
//      {
//          // Prompt the user for change owed, in cents
//          int cents;
//          do
//          {
//              cents = get_int("Change owed: ");
//          }
//          while (cents < 0);
//
//          // Calculate the number of coins needed
//          int quarters = cents / 25;
//          cents = cents % 25;
//
//          int dimes = cents / 10;
//          cents = cents % 10;
//
//          int nickels = cents / 5;
//          cents = cents % 5;
//
//          int pennies = cents; // Remaining cents are all pennies
//
//          // Sum up all coins
//          int total_coins = quarters + dimes + nickels + pennies;
//          printf("%i\n", total_coins);
//      }
//
