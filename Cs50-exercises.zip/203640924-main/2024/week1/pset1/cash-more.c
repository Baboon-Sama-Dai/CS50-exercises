#include <cs50.h>
#include <stdio.h>

// Function to calculate the checksum using the Luhn algorithm
int checksum(long card_number);

int main(void)
{
    // Ask the user for the credit card number
    long card_number = get_long("card_number: ");
    int card_length = 0;
    long first_digits = card_number;

    // Extract the first two digits or more
    while (first_digits >= 100)
    {
        first_digits = first_digits / 10;
    }

    // Calculate the card length
    long temp_card = card_number;
    while (temp_card > 0)
    {
        temp_card = temp_card / 10;
        card_length++;
    }

    // Validate card type based on checksum, length, and first digits
    if (checksum(card_number)) // Pass the original card_number to the checksum function
    {
        if (card_length == 15 && (first_digits == 34 || first_digits == 37))
        {
            printf("AMEX\n");
        }
        else if (card_length == 16 && first_digits >= 51 && first_digits <= 55)
        {
            printf("MASTERCARD\n");
        }
        else if ((card_length == 13 || card_length == 16) && first_digits / 10 == 4)
        {
            printf("VISA\n");
        }
        else
        {
            printf("INVALID\n");
        }
    }
    else
    {
        printf("INVALID\n");
    }

    return 0;
}

int checksum(long card_number)
{
    int sum = 0;
    int multiply = 0;

    while (card_number > 0)
    {
        int digit = card_number % 10;
        card_number /= 10;

        if (multiply)
        {
            digit *= 2;
            if (digit > 9)
            {
                digit = (digit % 10) + (digit / 10);
            }
        }
        sum += digit;
        multiply = !multiply;
    }
    return (sum % 10 == 0);
}
