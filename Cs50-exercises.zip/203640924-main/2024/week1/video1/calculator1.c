#include <stdio.h>
#include <cs50.h>

int main(void)
{
    int x = get_int("x: ");
    int y = get_int("y: ");

    // Types casting to avoid truncation
    float z = (float) x / (float) y;
    //Floating point imprecision (printf("%.5f\n", z))
    printf("%f\n", z);
}
