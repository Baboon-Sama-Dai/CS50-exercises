#include <stdio.h>
#include <cs50.h>

//FIRST STEP
    //Hello, world!
        //Let's write a "Hello, world!" program to complete the first step of Problem Set 1.


//SECOND STEP
    //Hello, me!
        //Let's write a "Hello, me!" program to complete the second step of Problem Set 1.
        //int main(void)

        //string first_name = get_string("First name: ");
        //string last_name = get_string("Last name: ");
        //printf("Hello, %s %s!\n", first_name, last_name);


//THIRD STEP
    //Hello, contact!
        //Let's write a program that stores (and prints out!) a user's contact information.
        //Includes: Name, Age, Phone number

int main(void)
{
    string first_name = get_string("First name: ");
    string last_name = get_string("Last name: ");
    int age = get_int("Your age: ");
    string phone = get_string("Phone number: ");

    printf("Contact details:\n");
    printf("My full name is %s %s\n", first_name, last_name);
    printf("Iam %i years old\n", age);
    printf("And my phone number is %s\n", phone);

}
