#include <stdio.h>
#include <cs50.h>

int main(void)
{
int x = get_int();
int y = get_int();
int counter = 0;
int counter++;

    if (x < y)
    {
        printf("x is less than y\n");
    }
    else (x > y)
    {
        printf("x is greater than y\n");
    }
    else
    {
        printf("x is equal to y\n");
    }
}
