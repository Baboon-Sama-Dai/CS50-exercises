#include <cs50.h>
#include <stdio.h>

int main(int argc, string argv[])
{
    //printf("hello, %s\n", argv[1]);//leave your name after the command line argument
    for(int i = 0; i < argc; i++)
    {
        printf(" %s\n", argv[i]);
    }
}
