#include <stdio.h>
#include <cs50.h>
#include <stdlib.h>

int main(int argc, string argv[])
{
    if(argc != 2)
    {
        printf("Usage: ./mario number\n");
        return 1;
    }
    int height = atoi(argv[1]);
}
