#include <cs50.h>
#include <stdio.h>

bool valid_triangle(float a, float b, float c);

int main(void)
{
    float a = get_float("Give me a first float: ");
    float b = get_float("Give me a second float: ");
    float c = get_float("Give me a third float: ");

    if(valid_triangle(a,b,c))
    {
        printf("The sum of the three side are able to make a triangle");
    }
    else
    {
        printf("The sum of the three side are not able to make a triangle");
    }
}

bool valid_triangle(float a, float b, float c)
{
    if(c < (a + b))
    {
        return true;
    }
    else
    {
        return false;
    }

}
