#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include <ctype.h>

int main(void)
{
    string s = get_string("Before: ");
    printf("After: ");
    for (int i = 0, n = strlen(s); i < n; i++)
    {
        //If Lowercase
        //if(s[i] >= 'a' && s[i] <= 'z')
        //{
            //Replace the by the ASCII code [i] minus their value in Uppercase
            //printf("%c", s[i] - 32);//Fragile technique...
            //printf("%c", s[i] - ('a' - 'A'));// Same for this one
            //printf("%c", toupper(s[i]));We may use this an easier way by itsel without conditions.
        //}
        //else
        //If it's another caractere than an alphabetique like [!], [@] etc...
        //{
            //printf("%c", s[i]);
        //}
        printf("%c", toupper(s[i]));// You can this function by itself!
    }
    printf("\n");
}
