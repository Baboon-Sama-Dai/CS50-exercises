#include <stdio.h>
#include <cs50.h>
#include <string.h>

int main(void)
{
    //whrite a program to check if an array of characters is in alphabetical order.
    //Assume the caracter are all uppercase.
    string phrase = get_string("Enter phrase: ");
    int length = strlen(phrase);
    for(int i = 0; i < length -1; i++)
    {
        //Check if character are NOT alphabetical order.
        if(phrase[i] > phrase[i + 1])
        {
           printf("Not in alphabetical order.\n");
           return 0;
        }
    }
    printf("Alphabetical order.\n");
    return 0;
}
