#include <stdio.h>
#include <cs50.h>
#include <string.h>

int main(void)
{
    string s = get_string("Input: ");
    printf("Output: ");
    int length = strlen(s);

    //An other calssy way to write this code
    //'n' Being a shorter way than length
    //for(int i = 0, n = strlen(s); i < n ;i++)
    for(int i = 0; i < length; i++)
    {
        printf("%c", s[i]);
    }
    printf("\n");
}
