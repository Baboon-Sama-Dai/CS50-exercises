#include <cs50.h>
#include <stdio.h>

bool valid_triangle(float x, float y, float z);

int main(void)
{
    float a = get_float("Give me a first float: ");
    float b = get_float("Give me a second float: ");
    float c = get_float("Give me a third float: ");

    if(valid_triangle(a,b,c))
    {
        printf("The sum of the three side are able to make a triangle");
    }
    else
    {
        printf("The sum of the three side are not able to make a triangle");
    }
}

bool valid_triangle(float x, float y, float z)
{
    if(x <= 0 || y <= 0 || z <= 0)
    {
        return false;
    }

    if((x + y <= z) || (x + z <= y) || (y + z <= x))
    {
        return false;
    }
    return true;
}

