#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include <ctype.h>

int POINTS[] = {1,3,3,2,1,4,2,4,1,8,5,1,3,1,1,3,10,1,1,1,1,4,4,8,4,10};

int score(string word);

int main(void)
{
    //Prompte user for input twice: Player1 / Player2
    string word1 = get_string("Baboon: ");
    string word2 = get_string("Jim: ");
    //Then program should print "P1 wins", "P2 wins" or "Tie"
        //Set 2 variable result
    int result1 = score(word1);
    int result2 = score(word2);
    //print the winner
    if (result1 > result2)
    {
        printf("Baboon wins with %i points!\n", result1);
    }
    else if (result1 < result2)
    {
        printf("Jim wins with %i points!\n", result2);
    }
    else
    {
        printf("Tie!\n");
    }
}
//Function that convert string into integer and stock them into an arrays of integer
int score(string word)
{
    // Keep track of score
    int score = 0;

    // Compute score for each character
    for (int i = 0, len = strlen(word); i < len; i++)
    {
        if (isupper(word[i]))
        {
            score += POINTS[word[i] - 'A'];
        }
        else if (islower(word[i]))
        {
            score += POINTS[word[i] - 'a'];
        }
    }
    return score;
}
