#include <stdio.h>
#include <cs50.h>
#include <string.h>

//int string_length(string s);

int main(void)
{
    string name = get_string("Name: ");
    int length = strlen(name);
    printf("%i\n", length);
}



//Function "strlen"
//int string_length(string s)
//{
//    int n = 0;
//    while (s[n] != '\0')
//    {
//        n++;
//    }
//    return n;
//}
