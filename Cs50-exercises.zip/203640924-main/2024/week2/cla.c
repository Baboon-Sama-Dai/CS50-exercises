//Command line argument
#include <stdio.h>

//You can replace by "int main(argc, string argv[])"
//arg,c == argument count
//arg,v == argument vector (usualy a term for an array)(liste)
int main(void)
{

}

