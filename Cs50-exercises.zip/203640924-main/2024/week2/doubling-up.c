#include <stdio.h>
#include <cs50.h>

int main(void)
{
    //Create an array of integer in which each integer is 2 times the value of the previous integer.
    int size = get_int("Enter size: ");
    int doubling[size];
    doubling[0] = 1;
    printf("%i\n", doubling[0]);

    for(int i = 1; i < size; i++)
    {
        doubling[i] = doubling[i - 1] * 2;
        printf("%i\n", doubling[i]);
    }
    //Print the array integer by integer.
}
