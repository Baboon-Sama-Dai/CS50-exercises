#include <stdio.h>
#include <cs50.h>
#include <string.h>

bool check_word(string word);

int main(void)
{
    string word = get_string("What's the secret word? ");
    if(check_word(word))
    {
        printf("You find the secret word!!!");
    }
    else
    {
        printf("Your wrong, try again!");
    }
}

bool check_word(string word)
{
    string password = "Please";
    if(strcmp(word, password) == 0)
    {
        return true;
    }
    return false;
}
