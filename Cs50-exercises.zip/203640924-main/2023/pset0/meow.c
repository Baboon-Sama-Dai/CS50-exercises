#include <stdio.h>
#include <cs50.h>
{
    int i = 0;
    while (i < 30)
    {
        printf("meow\n");
        i++;
    }


}
