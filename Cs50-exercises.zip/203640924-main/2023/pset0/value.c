#include <stdio.h>
#include <cs50.h>

int main(void)
{
    string first = get_string("What's your name? ");
    string last = get_string("How old are you? ");

    printf("hello, %s %s\n", first, last);

}
