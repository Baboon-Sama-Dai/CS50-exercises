#include <stdio.h>
#include <cs50.h>

int main(void)
{
    while (true)
    {
        printf("meow\n");
    }


}
