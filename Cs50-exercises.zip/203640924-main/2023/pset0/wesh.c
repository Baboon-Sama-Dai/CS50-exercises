#include <cs50.h>
#include <stdio.h>

int main(void)
if (x < y)
{
    printf("x is less than y\n");
}
else if (x > y)
{
    printf("x is grater than y\n"):
}
else (x == y)
{
    printf("x et egual a y\n");
}
