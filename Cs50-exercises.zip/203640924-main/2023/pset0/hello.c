#include <stdio.h>
#include <cs50.h>

int main(void)
{
    printf("Hello, world\n");
}
