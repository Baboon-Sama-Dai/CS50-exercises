#include <stdio.h>
#include <cs50.h>

int main(void)
{
    //Prompt the user for a starting number of llamas
    int start;
    do
    {
        start = get_int("Start size: ");
    }
    while (start < 9);

    //Prompt the user for a goal number of llamas
    int end;
    do
    {
        end = get_int("Final size: ");
    }
    while (end < start);

    //Add and subtract llamas every "year" until we reach the goal number of llamas
    int years = 0;
    while (start < end)
    {
        start += start / 3;
        start += start / 4;
        years++;
    }



    //Print the number of years it took to reach the goal number of llamas
    printf("It will need %i years to get to that final size of population!\n", years);

}
