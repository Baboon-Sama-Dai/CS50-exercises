#include <stdio.h>
#include <cs50.h>

int main(void)
{
    //ask for the name
    string i = get_string("What's your name? ");
    //"         " age
    int j = get_int("How old are you? ");
    //"         " phone number (use a string because the integer or long don't regognize the "0" and we don't need to calculate a phone number)
    string n = get_string("What is your phone number? ");
    //print the values back
    printf("Hi, my name is %s\nIam %i\nAnd my phone number is %s\n", i, j, n);





}
