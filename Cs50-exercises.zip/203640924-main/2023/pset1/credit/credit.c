#include <cs50.h>
#include <stdio.h>

int main(void)
{
    //Get the the credit card number
    long cdnumber = get_long("Enter your credit card number plz: ");
    //printf("Your credit card is ...")

    //ex: 4003600000000014
    //check all caracters and get back all 2 digit from the end stock them
    //and keep the other one stock somewhere else

    //long test = 4003600000000014 % 10;
    do
    {
        char test = get_char(cdnumber);
    }
    while (cdnumber = '\0');


    printf('%li\n', test);




}
