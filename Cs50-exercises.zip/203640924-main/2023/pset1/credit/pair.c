#include<stdio.h>
#include<cs50.h>


int main(void)
{
    int digit = 0;
    long pair = 0;
    int sum1 = 0;
    int sum2 = 0;
    long result;




    printf("Donne a moe: ");
    // Lecture des caractères jusqu'à la fin de ligne
    while ((digit = getchar()) != '\n')
    {
        if (pair % 2 == 0)
        {
            //printf("%c", digit);
            sum1 += digit - '0';
        }
        else
        {
            //printf("%c", digit);
            sum2 += digit - '0';
        }
        pair++;
    }


    result = (sum1 + sum2);
    bool estMastercard(char *numero)
    {
        int longueur = strlen(numero);

        if (longueur == 16)
        {
            int premierDeuxChiffres = (numero[0] - '0') * 10 + (numero[1] - '0');
            if (premierDeuxChiffres >= 51 && premierDeuxChiffres <= 55)
            {
            return true;
            }
    }

    return false;



    char numero[17];

    printf("Entrez le numéro de carte : ");
    scanf("%16s", numero);

    if (estMastercard(numero))
    {
        printf("Mastercard\n");
    } else
    {
        printf("Invalid\n");
    }

    return 0;
}








