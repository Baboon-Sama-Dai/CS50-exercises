#include <stdio.h>
#include <stdbool.h>
#include <string.h>

bool estMastercard(char *numero) {
    int longueur = strlen(numero);

    if (longueur == 16) {
        int premierDeuxChiffres = (numero[0] - '0') * 10 + (numero[1] - '0');
        if (premierDeuxChiffres >= 51 && premierDeuxChiffres <= 55) {
            return true;
        }
    }

    return false;
}

bool estDernierChiffreZero(int resultat) {
    if (resultat % 10 == 0) {
        return true;
    }
    return false;
}

int main() {
    char numero[17];
    int sum1 = 0, sum2 = 0, pair = 0, resultat = 0;
    char digit;

    printf("Entrez le numéro de carte : ");
    scanf("%16s", numero);

    while ((digit = getchar()) != '\n') {
        if (pair % 2 == 0) {
            sum1 += digit - '0';
        } else {
            sum2 += digit - '0';
        }
        pair++;
    }

    resultat = sum1 + sum2;

    if (estMastercard(numero)) {
        printf("Mastercard\n");
        if (estDernierChiffreZero(resultat)) {
            printf("Le dernier chiffre de la somme est un 0\n");
        } else {
            printf("Le dernier chiffre de la somme n'est pas un 0\n");
        }
    } else {
        printf("Invalid\n");
    }

    return 0;
}
