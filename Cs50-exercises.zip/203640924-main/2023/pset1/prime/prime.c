#include <cs50.h> // function from library
#include <stdio.h> // function from library
#include <stdbool.h> // function from library
#include <math.h> // function from library

// This is a function prototype or declaration.
//It declares a function named prime that takes an integer argument
//and returns a boolean value (true or false). The function is defined later in the code.
bool prime(int number);

int main(void)
{
//This declares an integer variable named min without initializing it.
    int min;
//This is a do-while loop that prompts the user to enter the minimum value.
//It keeps asking for input until a value greater than or equal to 1 is provided.
    do
    {
        min = get_int("Minimum: "); //This line uses the get_int function from the
        //cs50.h library to get an integer input from the user and assigns it to the min variable.
    }
    while (min < 1);
//This declares an integer variable named max without initializing it.
    int max;
//This is another do-while loop that prompts the user to enter the maximum value.
//It keeps asking for input until a value greater than min is provided.
    do
    {
        max = get_int("Maximum: ");//This line uses the get_int function to get an integer input
        //from the user and assigns it to the max variable.
    }
    while (min >= max);
//This is a for loop that iterates from min to max (inclusive) with a variable i.
//It executes the code inside the loop for each value of i
    for (int i = min; i <= max; i++)
    {
// This line checks if the current value of i is prime by calling the prime function with i as an argument.
//If the function returns true, the code inside the if statement is executed.
        if (prime(i))
        {
            printf("%i\n", i);//This line uses the printf function to display the value of i as output.
            //The %i format specifier is used to print an integer, and \n is a newline character to add a line break.
        }
    }
}
//This is the definition of the prime function. It takes an integer argument number and returns a boolean value.
bool prime(int number)
{
//This line checks if number is less than 2. If it is, the function returns false since prime numbers are greater than or equal to 2.
    if (number < 2)
    {
        return false;
    }
//This line calculates the square root of number using the sqrt function from the math.h library and assigns it to the sqrtNum variable.
    int sqrtNum = sqrt(number);
    //This is a for loop that iterates from 2 to sqrtNum (inclusive) with a variable i.
    //It checks for divisors of number by testing if number is divisible by i.
    for (int i = 2; i <= sqrtNum; i++)
    {
        //This line checks if number is divisible evenly by i. If it is, the function returns false since number is not prime.
        if (number % i == 0)
        {
            return false;
        }
    }
//If the loop completes without finding a divisor, the function returns true, indicating that number is prime.
    return true;
}
