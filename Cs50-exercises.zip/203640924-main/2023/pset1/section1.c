#include <stdio.h>
#include <cs50.h>

int main(void)
//So if you say this in English here, we're going to create an integer variable. Notice how this type aligns with this type here.
//Named calls, the name lines up here.
//That gets, or that kind of stores this value 4, in this instance.

//int(types) | Calls(name) | =(assignment operator) | 4(value) | ;(semicolon)
{
    int calls = 4;
    calls = calls / 2;
}
