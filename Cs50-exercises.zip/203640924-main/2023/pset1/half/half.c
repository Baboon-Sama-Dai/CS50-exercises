// Calculate your half of a restaurant bill
// Data types, operations, type casting, return value

#include <cs50.h>
#include <stdio.h>

float half(float bill, float tax, int tip);



int main(void)
{
    float bill_amount = get_float("Bill before tax and tip: ");
    float tax_percent = get_float("Sale Tax Percent: ");
    int tip_percent = get_int("Tip percent: ");

    float owed_amount = half(bill_amount, tax_percent, tip_percent);
    printf("You will owe $%.2f each!\n", owed_amount);

    return 0;
}

// TODO: Complete the function
float half(float bill, float tax, int tip)

{
    float total_amount = bill + (bill * tax / 100);
    float tip_amount = total_amount * tip / 100;
    float final_amount = total_amount + tip_amount;
    float amount_per_person = final_amount / 2;
    return amount_per_person;
}
