//Exercice 2 - Conditional (Condition) :
//Écrivez un programme en langage C qui demande à l'utilisateur d'entrer un nombre et affiche s'il est pair ou impair.
#include <stdio.h>

int main()
{

    int nbr;
    do
    {
        printf("Entrez un entier:\n");
        scanf("%i", &nbr);
    }
    while (nbr < 0 );

        if (nbr % 2 == 0)
        {
        printf("Le nombre %i est paire.\n", nbr);
        }
        else
        {
        printf("Le nombre %i est impair.\n", nbr);
        }

    return 0;
}
