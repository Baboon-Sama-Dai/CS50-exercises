//Exercice 1 - Loop (Boucle) :
//Écrivez un programme en langage C qui affiche les nombres de 1 à 10 à l'aide d'une boucle for.
#include <stdio.h>

int main(void)
{
    for(int i = 1; i <= 10; i++)
    {
        printf("%i\n", i);
    }
    return 0;
}
