#include <cs50.h>
#include <stdio.h>

int main(void)
{
int h;
    do
    {
        h = get_int("Please choose a number between 1 to 8: ");
    }
    while (h < 1 || h > 8);

        for (int s = 1; s <= h; s++) {
        // Print dots (spaces) before the hash symbols
        for (int p = 1; p <= h - s; p++) {
            printf(" ");
        }

        // Print hash symbols
        for (int a = 1; a <= s; a++) {
            printf("#");
        }

        printf("\n"); // Move to the next line
    }



}
