#include <stdio.h>
#include<cs50.h>

//we need to remind that there is a function down below the main that we use in main
//(Function declaration)= yes ---> (';')
float multiple(float a, float b);

int main(void)
{
    //initialize the 2 input from the user
    float a = get_float("a: ");
    float b = get_float("b: ");
    // we call the function and we assign the value from result to the variable c
    float c = multiple( a, b);
    //printf the result
    printf("The result of %f * %f = %f\n", a, b, c);

}
//we create our function here(Function definition)= no ---> (';')
//type name(argument_list)
float multiple(float a, float b)
{
    //calcul multiply 2 floating point number and transfert to our variable result
    float result = a * b;
    // return the value result
    return result;
}
