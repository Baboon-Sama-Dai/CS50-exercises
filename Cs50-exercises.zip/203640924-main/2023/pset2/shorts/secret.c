#include <stdio.h>
#include <cs50.h>
#include <string.h>
//Function declaration type boolean return value type string
bool check(string);

int main(void)
{
    //Get the user to prompt a word and put it to the variable "magic"
    string magic = get_string("What's the magic word? ");
    //we call the function check that return our boolean value stock in "magic"
    //and we put it into our variable type boolean "correct"
    bool correct = check(magic);
    //we check if the condition "correct" is true
    if (correct == true)
    {
        //if true printf if not do nothing
        printf("Yeaaaah\n");
    }

}
//Function definition
//Our function check if the user prompt "magic" and the "password" are true("please")
bool check(string magic)
{
    //initialize our variable type string and we give it the value "Please"
    string password = "Please";

    //We check if the two string are egual by using "strcmp" that is necesary to compare two string!!!
    //And return me '0' if the two string are egaul
    if (strcmp(magic, password) == 0)
    {
        return true;
    }
    // if not return false and stop the programme
    return false;
}
