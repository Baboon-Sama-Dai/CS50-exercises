#include <stdio.h>
#include <cs50.h>

//initialize commande line argument  int argc= compte argument
//"                                " string argv= vecteur argument
int main(int argc, string argv[])
{
    //For loop to go thru each cla
    for (int i = 0; i < argc; i++)
    {
        //printf each argv
        printf("argv[%i] is %s\n", i, argv[i]);
    }
}
