#include <stdio.h>
#include <cs50.h>

int main(int argc, string argv[])
{
    // For loop to go thru each cla
    for (int i = 0; i < argc; i++)
    {
        //printf each first char of the argv arrays
        printf("%c %c", argv[1][0], argv[2][0]);
        return 0;
    }


}
