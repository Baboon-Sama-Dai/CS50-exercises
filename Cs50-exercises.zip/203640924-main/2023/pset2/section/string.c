#include <stdio.h>
#include <cs50.h>
#include <string.h>

int main(void)
{
    // initialize the variable "name" as a string
    string name = "Emma";
    // function "strlen" getting the length of our string "name" into our variable length
    int length = strlen(name);

    //for loop to printf all the char 1 by 1.
    for (int i = 0; i < length; i++)
    {
        // (%c)= Get the string of char
        // (%i)= Get the integers of ascii charte
        printf("%c ", name[i]);
    }
    printf("\n");
}
