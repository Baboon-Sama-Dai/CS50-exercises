#include <stdio.h>
#include <cs50.h>
#include <string.h>

int main(void)
{
    // Get string from the user
    string word = get_string("Word: ");

    //Get the length of the user value "word" and give it to the variable "word_length"
    int word_length = strlen(word);
    //For loop to check every char - 1
    for (int i = 0; i < word_length -1; i++)
    {
        //check if NOT alphabetical (i.e., "ba")
        if (word[i] > word[i + 1])
        {
            printf("No\n");
            //Need the return 0 value to end the programme at this stage
            return 0;
        }
    }
    printf("yes\n");
    return 0;

}
